import { Link } from "react-router-dom";
import {useState} from 'react';
import './stylecardapio.css';
import Img1 from "./hamb1.jpg";
import Img2 from "./hamb2.jpg";
import Img3 from "./hamb3.jpg";
import Img4 from "./hamb4.jpg";
import Img5 from "./hamb5.jpg";
import Img6 from "./hamb6.jpg";
import Img7 from "./b1.jpg";
import Img8 from "./b2.jpg";
import Img9 from "./b3.jpg";

function Cardapio(){


    return(

        <section class="popular" id="popular">

                <h1 class="heading"><span>Cardapio</span></h1>
<br></br>
                <div class="box-container">

                    <div class="box">
                        <span class="price"> R$30 </span>
                        <img class="image" src={Img1} alt="" />
                            <h3> Yellow Bacon Burguer</h3>
                           <p>
                            pão, hamburguer, cebola caramelizada, catupiry, gema.
                           </p>
                         
                        </div>
                    <div class="box">
                        <span class="price"> R$20 </span>
                        <img class="image" src={Img2} alt="" />
                            <h3>Pineapple Burguer</h3>
                            <p>
                            pão, hamburguer,  abacaxi caramelizada com bacon, coentro
                            acompanhado com fritas.
                           </p>
                         
                        </div>
                    <div class="box">
                        <span class="price"> R$30 </span>
                        <img class="image" src={Img3} alt="" />
                            <h3>Tomate Burguer</h3>
                            <p>
                            pão, hamburguer, tomate cereja, hortelã, queijo
                           </p>
                           
                        </div>
                    <div class="box">
                        <span class="price"> R$36,50 </span>
                        <img class="image" src={Img4} alt="" />
                            <h3>X-salada</h3>
                            <p>
                            pão, hamburguer, cebola roxa, salada, queijo, tomate
                           </p>

                        </div>
                    <div class="box">
                        <span class="price"> R$46,90 </span>
                        <img class="image" src={Img5} alt="" />
                            <h3>Vegano</h3>
                           <p>
                           pão, abacaxi caramelizado, pepino, molho especial
                           </p>
                           
                        </div>
                    <div class="box">
                        <span class="price"> R$38,50 </span>
                        <img class="image" src={Img6} alt="" />
                            <h3>Bacon Burguer</h3>
                            <p>
                            pão, hamburguer, cebola caramelizada, Bacon acompanhado com fritas
                           </p>
                      
                        </div>
               


                <div class="box">
                        <span class="price"> R$6,00 </span>
                        <img class="image" src={Img7} alt="" />
                            <h3>Cerveja Artesanal</h3>
                           
                        </div>

                        <div class="box">
                        <span class="price"> R$5,00 </span>
                        <img class="image" src={Img8} alt="" />
                            <h3>Refrigerante</h3>
                            <p>Coca-Cola, Guaraná, Sprite</p>
                           
                        </div>

                        <div class="box">
                        <span class="price"> R$4,00 </span>
                        <img class="image" src={Img9} alt="" />
                            <h3>Água</h3>
                            <p>Com e Sem Gás</p>

                           
                        </div>
                        </div>
                

            </section>
        
    
    )
    }

export default Cardapio;