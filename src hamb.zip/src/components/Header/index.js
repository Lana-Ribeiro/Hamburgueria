import { Link } from "react-router-dom";
import './style.css';
import Img from "./Rendezvous.png";

function Header(){



    return(
        
      
        <header >
            
        <img class="logoheader" src={Img}/>
                    
            
        <div className="menu">
            <br/>
            <Link to ='/'>Home</Link> 
            <Link to ='/cardapio'>Cardapio</Link>
            <Link to ='/sobrenos'>Sobre nós</Link>
             <Link to ='/Cadastro'>Login</Link> 
        
        </div>
        </header>
    )
}

export default Header;