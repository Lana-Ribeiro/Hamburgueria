import { Link } from "react-router-dom";
import style from './stylehome.css';
import Img from "./rendback.png";

function Home(){



    return(
        <div style={{ backgroundImage: "url(/rendback.png)" }} >

              <img class="hom" src={Img}/>

            <br></br>
            
        </div>
    )
}

export default Home;