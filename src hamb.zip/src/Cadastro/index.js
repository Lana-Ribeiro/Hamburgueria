import { Link } from "react-router-dom";
import {useState} from 'react';
import './cadstyle.css';

function Cadastro(){

    const [nome, setNome]= useState('.....');
    const [endereco, setendereco]= useState('.....');


    const [dadosCliente, setDadosCliente]=useState({
        Login:"-----------",
        Senha:"------------"
     })
     

    function cadastrarCliente(evento){
        evento.preventDefault();
        alert("Cliente cadastrado com sucesso!!!!");

        setDadosCliente({

            nomeCliente:nome,
            enderecoCliente:endereco

        })
    }



    return(
        <div id ="cad" className="cadastro">
       
            <form onSubmit={cadastrarCliente} className="results"> 
            

        <div id ="login">

        <h2> Login </h2>
            <input id="login" placeholder="Login"  valeu={nome} 
            onChange={(evento)=>setNome(evento.target.value)}></input>

        </div>
       
               
        <div id ="senha">

        <h2> Senha </h2>
            <input id="senha" type="password" placeholder="Senha"  valeu={endereco} 
            onChange={(evento)=>setendereco(evento.target.value)}>

            </input>
        </div>
             
    <br>
    </br>

            
            <button type="submit">Cadastrar</button>
            
            </form>
            <br></br>

        
    
        </div>
        
    )
}

export default Cadastro;