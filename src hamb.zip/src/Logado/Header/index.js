import { Link } from "react-router-dom";
import './style.css';
import Img from "./Rendezvous.png";

function Header(){



    return(
        
      
        <header >
            
        <img class="logoheader" src={Img}/>
                    
            
        <div className="menu">
            <br/>
            <Link to ='/'>Comanda</Link> 
            <Link to ='/coziha'>Cozinha</Link>
            <Link to ='/cadastropratos'>Cadastro de Pratos</Link>
             <Link to ='/cadastrofuncionarios'>Cadastro de Funcionários</Link> 
        
        </div>
        </header>
    )
}

export default Header;