import { Link } from "react-router-dom";
import { Style } from './stylesobrenos.css';
import Img10 from "./marcos.jpg";
import Img11 from "./ivo.jpg";
import Img12 from "./thomas.jpg";
import Img13 from "./lana.jpg";


function SobreNos(){



    return(

        <div id="sobrenos">
            <h1 align='center'>Sobre nós</h1>

            <br>
            </br>

         <p>
        A Rendezvous foi fundada em 2019 na França com tradiçoes e culturas diferenciadas para trazer maior saciedade e conforto para nossos clientes.
        </p>
        <br>
        </br>
 
            <br>
            </br>


         <p>
                Missão:
            Servir aos CLIENTES pratos elaborados com CARINHO e QUALIDADE,com EXCELÊNCIA no atendimento, em um ambiente limpo e agradável.
         </p>
         <br>
            </br>

            

            <p>
            Visão:
            Ser uma empresa com rentabilidade satisfatória aos franquiados  com qualidade e referência na gastronomia, sendo um atrativo turístico.
            </p>
            <br>
            </br>
             <p>
             Valores:
             QUALIDADE – Compromisso com o aprimoramento dos produtos e serviços.
            COMPROMETIMENTO – Identificação com a missão da organização
            DEDICAÇÃO – Promoção ao trabalho com afinco
            TRADIÇÃO – Preservar usos e costumes da organização
            ORGANIZAÇÃO – Existência de normas claras e explícitas
            HONESTIDADE – assumir uma postura honesta e sincera nas atitudes.
            EFICIÊNCIA – Executar as tarefas da organização de forma certa
             </p>

             <section class="review" id="review">

                <br></br>
                <br></br>
                <br></br>
                <br></br>

<h1>Donos</h1>

<div class="box-container">

    <div class="box">
           <img  src={Img10}/>
        <h3>Marcos Rosa</h3>
    </div>

    <div class="box">
         <img  src={Img11}/>
        <h3>Ivo Gouveira</h3>
    </div>

    <div class="box">
    <img  src={Img12}/>
        <h3>Thomas</h3>
    </div>

    <div class="box">
    <img  src={Img13}/>
        <h3>Lana Ribeiro</h3>
    </div>

    

</div>

</section>

        </div>
        
    )
}

export default SobreNos;